This is a veru calculater which adds, subtracts , divides
and multiplies the givrn twi values